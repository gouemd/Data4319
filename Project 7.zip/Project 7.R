
##########   data frame  ############

# predicting heart disease 

heart <- read.table(file.choose(), sep = ",")
heart(head)

# changing columns names
colnames(heart)<- c("Age", "Sex", "Chestpain", "Restbps", "Chol","Fastingbs", "Restecg", "MaxHr", "Exang", "STdepress","Slope", "ColoredVess", "Thal", "Diagnosis")
head(heart, 20)


attach(heart)

# assigning heart.1 to diagnosis factor

heart.1 <- subset(heart, heart$Diagnosis==0 | heart$Diagnosis==1)

dim(heart.1)

train.index<- sample(1:nrow(heart.1), 0.8*nrow(heart.1))
train.data <- heart.1[train.index,    ]   #train dataset 80% randomly chosen
test.data <- heart.1[-train.index,   ]    #test dataset 20% randomly chosen



#########  Logistic model model ##############

Diagnosis.train <- train.data$Diagnosis  # different with Diagnosis of heart data

Diagnosis.test <-  test.data$Diagnosis  # different with Diagnosis of heart

log.mod<- glm(Diagnosis.train~ ., family=binomial (link="logit"), data=train.data)

## Prediction of the full model
prediction <- predict(log.mod, newdata=test.data, type="response")


table(Diagnosis.test, ifelse(prediction >.5, "1","0") )


##############  model with factors ##################

## Some variables are numeric and some are factors. We inverstigate the factors
## We might seperate the data into factors and numeric


## aov model with factors

Sex.fact <- factor(Sex)
Chestpain.fact <- factor(Chestpain)
Fastingbs.fact <- factor(Fastingbs)
Restecg.fact <- factor(Restecg)
Exang.fact <- factor(Exang)
ColoredVess.fact <- factor(ColoredVess)

aov.mod <- aov(Diagnosis ~ Sex.fact +Chestpain.fact+Fastingbs.fact + Exang.fact +ColoredVess)

summary(aov.mod)

## plot the effects
plot.design(Diagnosis ~ Sex.fact +Chestpain.fact+Fastingbs.fact + Exang.fact +ColoredVess)

install.packages("BsMD")
library(BsMD)

DanielPlot(aov.mod, half=TRUE,code=FALSE )

effects <- aov.mod$coefficients



install.packages("gplots")
library(gplots)

LenthPlot(aov.mod, alpha=.1, srt=90 )
angleAxis(1, labels = names(effects[-1]), srt=90)

install.packages("BsMD")
library(BsMD)
DanielPlot(aov.mod)

###############   Reduced model  ##############

summary(log.mod)


install.packages("MASS")
library(MASS)


log.mod.red <- stepAIC(log.mod)  # reduced model

prediction <- predict(log.mod.red, newdata=test.data, type="response") # prediction of reduced model

table(Diagnosis.test, ifelse(prediction >.5, "1","0") )

##########  Chi Square test on Factors ############


# Gender
chisq.test(Diagnosis.train,train.data$sex)    # gender, there are no difference of Gender


## age

boxplot(train.data$Age ~ train.data$Diagnosis)
t.test(train.data$Age, train.data$Diagnosis)     # Age is a significant factor 


# level of chest pain
chisq.test(Diagnosis.train,train.data$cp)   #  chest pain is a significant factor 



# Slope in the ECG
chisq.test(Diagnosis.train,train.data$Slope)  #  slope in ECGis a significant factor 


# STdepress in the EKG
chisq.test(Diagnosis.train,train.data$STdepress)  # st depression is a significant factor 
